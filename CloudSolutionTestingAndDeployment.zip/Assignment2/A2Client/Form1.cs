﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using A2Logic;
using System.Net;
using System.IO;

namespace A2Client
{
    public partial class Form1 : Form
    {
        private const int FIRST_VALUE = 1;
        private const int SECOND_VALUE = 2;

        private const int KEY = 0;
        private const int VALUE = 1;

        private readonly char[] DELIMITER = { ',' };

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String source = comboBox1.Text;
            WebClient webClient = new WebClient();
            Stream aStream = webClient.OpenRead(source);
            StreamReader aReader = new StreamReader(aStream);

            ConfigData cd = new ConfigData();

            cd.runtimeValues = new Dictionary<int, float>();
            cd.processorFrequencies = new Dictionary<int, float>();

            while (!aReader.EndOfStream)
            {
                String line = aReader.ReadLine().Trim();

                if (Utility.matchLine(line, "PROGRAM-MAXIMUM-DURATION"))
                {
                    String[] values = Utility.extractConfig(line, DELIMITER);
                    cd.programMaximumDuration = float.Parse(values[FIRST_VALUE]);
                }

                if (Utility.matchLine(line, "PROGRAM-TASKS"))
                {
                    String[] values = Utility.extractConfig(line, DELIMITER);
                    cd.programTasks = int.Parse(values[FIRST_VALUE]);
                }

                if (Utility.matchLine(line, "PROGRAM-PROCESSORS"))
                {
                    String[] values = Utility.extractConfig(line, DELIMITER);
                    cd.programProcessors = int.Parse(values[FIRST_VALUE]);
                }

                if (Utility.matchLine(line, "RUNTIME-REFERENCE-FREQUENCY"))
                {
                    String[] values = Utility.extractConfig(line, DELIMITER);
                    cd.referenceFrequency = float.Parse(values[FIRST_VALUE]);
                }

                if (Utility.matchLine(line, "TASK-ID,RUNTIME"))
                {
                    int count = 0;
                    String key_value_line;
                    while (count < cd.programTasks)
                    {
                        key_value_line = aReader.ReadLine().Trim();
                        String[] values = Utility.extractConfig(key_value_line, DELIMITER);
                        cd.runtimeValues.Add(int.Parse(values[KEY]), float.Parse(values[VALUE]));
                        count++;
                    }
                }

                if (Utility.matchLine(line, "PROCESSOR-ID,FREQUENCY"))
                {
                    int count = 0;
                    String key_value_line;
                    while (count < cd.programProcessors)
                    {
                        key_value_line = aReader.ReadLine().Trim();
                        String[] values = Utility.extractConfig(key_value_line, DELIMITER);
                        cd.processorFrequencies.Add(int.Parse(values[KEY]), float.Parse(values[VALUE]));
                        count++;
                    }
                }
            }
            aReader.Close();

            LocalWS1.ServiceClient sc = new LocalWS1.ServiceClient();
            LocalWS2.ServiceClient sc2 = new LocalWS2.ServiceClient();
            LocalWS3.ServiceClient sc3 = new LocalWS3.ServiceClient();

            //AmazonWS1.ServiceClient a1 = new AmazonWS1.ServiceClient();
            //AmazonWS2.ServiceClient a2 = new AmazonWS2.ServiceClient();
            //AmazonWS3.ServiceClient a3 = new AmazonWS3.ServiceClient();
            

            if (cd.programTasks < 10)
            {
                richTextBox1.Text = sc.GetData(cd);
            }
            else if (cd.programTasks >= 10 && cd.programTasks < 18)
            {
                richTextBox1.Text = sc2.GetData(cd);
            }
            else
            {
                richTextBox1.Text = sc3.GetData(cd);
            }
        }
    }
}
