﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using A2Logic;

// NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service" in code, svc and config file together.
public class Service : IService
{
    public Dictionary<int, int[,]> finalArray = new Dictionary<int, int[,]>();
    public int[,] allocy;
    public int count = 1;

    public void bruteForce(int t, int p, int[,] alloc, int level, Dictionary<int, int[,]> output, float[,] runtimeValues, float maxRuntime, Dictionary<int, float> freq)
    {
        if (output.Count == 10)
        {
            return;
        }
        if (level == 0)
        {
            if (Utility.checkIfAllTasksAllocated(t, alloc))
            {
                if (Utility.underMaxRuntime(p, alloc, runtimeValues) <= maxRuntime)
                {
                    if (Utility.calculateEnergyUsage(p, alloc, freq, runtimeValues) < 3940)
                    {
                        output[count] = (int[,])alloc.Clone();
                        count++;
                    }
                }
            }
        }
        else
        {
            for (int j = 1; j <= p; j++)
            {
                alloc[level, j] = 1;
                if (Utility.findTotalRuntime(j, alloc, runtimeValues) > maxRuntime)
                {
                    alloc[level, j] = 0;
                    continue;
                }
                alloc[level, j] = 0;
                if (Utility.isAllocated(level, alloc))
                {
                    continue;
                }
                else
                {
                    alloc[level, j] = 1;
                    bruteForce(t, p, alloc, level - 1, output, runtimeValues, maxRuntime, freq);
                    alloc[level, j] = 0;
                }
            }
        }
    }

    public string GetData(ConfigData cd)
    {
        allocy = new int[cd.programTasks + 1, cd.programProcessors + 1];
        float[,] runtimeTable = Utility.calculateActualRuntimeTable(cd.programTasks, cd.programProcessors, cd.referenceFrequency, cd.runtimeValues, cd.processorFrequencies);
        bruteForce(cd.programTasks, cd.programProcessors, allocy, cd.programTasks, finalArray, runtimeTable, cd.programMaximumDuration, cd.processorFrequencies);
        return Utility.displayValues(finalArray, cd.programProcessors, cd.processorFrequencies, runtimeTable);
    }
}
