﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2Logic
{
    public class ConfigData
    {
        public float programMaximumDuration { get; set; }
        public int programTasks { get; set; }
        public int programProcessors { get; set; }

        public float referenceFrequency { get; set; }

        public Dictionary<int, float> runtimeValues { get; set; }
        public Dictionary<int, float> processorFrequencies { get; set; }
    }
}
