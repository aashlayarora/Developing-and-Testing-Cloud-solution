﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace A2Logic
{
    public class Utility
    {
        public static bool matchLine(String line, String search)
        {
            if (line.StartsWith(search))
            {
                return true;
            }

            return false;
        }

        public static String[] extractConfig(String line, char[] delimiter)
        {
            String[] result = line.Split(delimiter);
            return result;
        }

        public static String displayValues(Dictionary<int, int[,]> result, int p, Dictionary<int, float> freq, float[,] runtimeValues)
        {
            String output = null;

            for (int i = 1; i <= result.Count; i++)
            {
                output += "Allocation " + i.ToString() + "\n";
                output += "Runtime - " + underMaxRuntime(p, result[i], runtimeValues).ToString() + "\n";
                output += "Energy Consumed - " + calculateEnergyUsage(p, result[i], freq, runtimeValues).ToString() + "\n";

                //Populate Allocation Matrix for output
                for (int x = 1; x < result[i].GetLength(1); x++)
                {
                    for (int y = 1; y < result[i].GetLength(0); y++)
                    {
                        output += (result[i][y, x] + ",");
                    }
                    output += "\n";
                }

                output += "\n";
            }

            return output;
        }

        public static float[,] calculateActualRuntimeTable(int t, int p, float refFrequency, Dictionary<int, float> refRuntime, Dictionary<int, float> processorFrequencies)
        {
            float[,] result = new float[t + 1, p + 1];

            foreach (KeyValuePair<int, float> task in refRuntime)
            {
                foreach (KeyValuePair<int, float> processor in processorFrequencies)
                {
                    result[task.Key, processor.Key] = task.Value * refFrequency / processor.Value;
                }
            }

            return result;
        }

        public static bool isAllocated(int t, int[,] alloc)
        {
            for (int i = 1; i < alloc.GetLength(1); i++)
            {
                if (alloc[t,i] == 1)
                {
                    return true;
                }
            }

            return false;
        }

        public static float findTotalRuntime(int p, int[,] alloc, float[,] values)
        {
            float totalRuntime = 0;
            for (int i = 1; i < alloc.GetLength(0); i++)
            {
                if (alloc[i,p] == 1)
                {
                    totalRuntime += values[i, p];
                }
            }

            return totalRuntime;
        }

        public static float calculateEnergyUsage(int p, int[,] alloc, Dictionary<int, float> freq, float[,] runtimeValues)
        {
            float totalEnergyUsage = 0;
            for (int i = 1; i <= p; i++)
            {
                totalEnergyUsage += ( (10 * freq[i] * freq[i]) - (25 * freq[i]) + 25 ) * findTotalRuntime(i, alloc, runtimeValues);
            }

            return totalEnergyUsage;
        }

        public static bool checkIfAllTasksAllocated(int t, int[,] alloc)
        {
            for (int i = 1; i <= t; i++)
            {
                if (isAllocated(t, alloc))
                {
                    continue;
                }
                else
                {
                    return false;
                }
            }
            return true;
        }

        public static float underMaxRuntime(int p, int[,] alloc, float[,] values)
        {
            float totalRuntime = 0;
            for (int i = 1; i <= p; i++)
            {
                float tmp = findTotalRuntime(i, alloc, values);
                if (totalRuntime < tmp)
                {
                    totalRuntime = tmp;
                }
                
            }

            return totalRuntime;
        }
    }
}
